#!/bin/bash

export DISPLAY=:
./tryme.py > tryme.out 2> tryme.err

