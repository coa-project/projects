#!/usr/bin/env python3

import mpcoaenv as cf
from bokeh.io import output_file, save
import os

output_file("tryme.html")
cf.map()
os.system("cp tryme.html tryme.copy.html")

output_file("tryme2.html")
cf.plot(option="sumall")
os.system("cp tryme2.html tryme2.copy.html")

